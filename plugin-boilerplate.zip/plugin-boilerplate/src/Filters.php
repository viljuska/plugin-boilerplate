<?php
/**
 * @package Boiler
 * @author  Stefan Jocić
 */

namespace Boiler;

use Boiler\Abstracts\MainInterface;
use Boiler\Traits\Singleton;

class Filters extends MainInterface {
	use Singleton;
}
