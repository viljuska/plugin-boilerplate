<?php
/**
 * @package Boiler
 * @author  Stefan Jocić
 */

namespace Boiler;

use Boiler\Abstracts\MainInterface;
use Boiler\Traits\Singleton;

class Actions extends MainInterface {
	use Singleton;
}
